import React from 'react'
import About from './Pages/About'
import Home from './Pages/Home'
import Navbar from './Pages/Navbar'


const App = () => {


  return (
    <>
      <Navbar />
      <Home />
      <About />
    </>
  )
}



export default App

// let Mode={
//   mode:mode,
//   setMode:setMode
// }

// Mode.mode
// Mode.setmode

// let {mode,setMode}=Mode

// mode

